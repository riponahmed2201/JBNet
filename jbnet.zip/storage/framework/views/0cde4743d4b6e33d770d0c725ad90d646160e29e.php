<?php $__env->startSection('main-content'); ?>
    company profile
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\dev\jbnet\resources\views/frontend/aboutUs/companyProfile.blade.php ENDPATH**/ ?>