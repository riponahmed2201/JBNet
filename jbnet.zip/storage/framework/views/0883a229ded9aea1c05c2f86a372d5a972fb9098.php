<?php $__env->startSection('main-content'); ?>
    <section style="padding:50px;background:#dedede;margin:50px;">
        <div class="container">
            <div class="row">
                <div class="col-md-12 imgceo">
                    <style>
                        .imgceo img {
                            float: left;
                            margin-right: 15px;
                        }

                        .imgceo h3 {
                            margin-bottom: 15px;
                            text-decoration: none;
                        }
                    </style>
                    <img width="150" height="150" src="<?php echo e(asset('frontend/images/shahin.jpg')); ?>"
                         class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="">
                    <h3><b>CEO MESSAGE</b></h3>
                    <p>
                    </p>
                    <p>JBNet brings you nearer to your friends and family with a single click that was never
                        easier before. We believe in creating a long term relation with our valuable customers
                        not restricted within business communications but also sales and on request services
                        which we are glad to provide anytime.
                        How cheap essays online to write an academic summary to understand how to write an
                        academic summary effectively, you need to answer a few basic questions and take certain
                        steps to get higher grades.</p>
                    <p></p>

                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\dev\jbnet\resources\views/frontend/aboutUs/ceoMessage.blade.php ENDPATH**/ ?>