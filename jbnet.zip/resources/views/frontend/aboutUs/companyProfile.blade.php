@extends('master')

@section('main-content')
    company profile
@endsection
